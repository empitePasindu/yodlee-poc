# AccountAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zip** | **str** |  | [optional] 
**country** | **str** |  | [optional] 
**address3** | **str** |  | [optional] 
**address2** | **str** |  | [optional] 
**city** | **str** |  | [optional] 
**source_type** | **str** |  | [optional] 
**address1** | **str** |  | [optional] 
**street** | **str** |  | [optional] 
**state** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


