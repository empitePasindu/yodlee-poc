# ContainerAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bank** | [**TransactionDays**](TransactionDays.md) |  | [optional] 
**loan** | [**TransactionDays**](TransactionDays.md) |  | [optional] 
**creditcard** | [**TransactionDays**](TransactionDays.md) |  | [optional] 
**investment** | [**TransactionDays**](TransactionDays.md) |  | [optional] 
**insurance** | [**TransactionDays**](TransactionDays.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


